import React, { useState, useEffect, useCallback } from 'react';
import Spin from '@iso/ui/Antd/Spin/Spin';
import Modal from '@iso/ui/Antd/Modal/Modal';
import Container from '@iso/ui/UI/Container/Container';
import AvatarCard from '@iso/components/AvatarCard/AvatarCard';
import ModuleList from './ModuleList/ModuleList';
import Projects from './Projects/Projects';
import CompanyList from './Companies/Companies';
import Wrapper, { Banner, Navigation, ContentWrapper } from './Profile.styles';
import { useSelector, useDispatch } from 'react-redux';
import profileActions from '@iso/redux/profile/actions';

const MyProfile = () => {
  const data = useSelector(state => state.profile.data);
  const loading = useSelector(state => state.profile.loading);
  const dispatch = useDispatch();
  const getProfile = useCallback(
    () => dispatch(profileActions.fetchProfileDataStart()),
    [dispatch]
  );

  const [active, setActive] = useState('moduleList');
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    getProfile();
  }, [getProfile]);

  const handleMenu = type => {
    if (type === 'moduleList') {
      setActive(type);
    }
    if (type === 'project') {
      setActive(type);
      setVisible(true);
    }
    if (type === 'companies') {
      setActive(type);
      setVisible(true);
    }
  };

  const handleCancel = () => {
    setVisible(false);
    setActive('moduleList');
  };

  return (
    <Wrapper>
      {loading !== true ? (
        <>
          <Banner
            className="profile-banner"
            style={{ backgroundImage: `url(${data.profile_bg})` }}
          >
            <Container className="container">
              <AvatarCard
                avatar={data.avatar}
                name={data.name}
                username={data.username}
              />
            </Container>
          </Banner>

          <Navigation className="navigation">
            <Container className="container">
              <ul className="menu">
                <li
                  className={active === 'moduleList' ? 'active' : ''}
                  onClick={() => handleMenu('moduleList')}
                >
                  <strong>{data.post.length}</strong> 作品截圖
                </li>
                <li
                  className={active === 'project' ? 'active' : ''}
                  onClick={() => handleMenu('project')}
                >
                  <strong>{data.projects.length}</strong> 專案列表
                </li>
                <li
                  className={active === 'companies' ? 'active' : ''}
                  onClick={() => handleMenu('companies')}
                >
                  <strong>{data.companies.length}</strong> 曾經任職
                </li>
              </ul>
            </Container>
          </Navigation>

          <ContentWrapper>
            <Container className="container">
              <ModuleList
                avatar={data.avatar}
                username={data.username}
                data={data.post}
              />
              <Modal
                wrapClassName="follow-modal"
                visible={visible}
                onCancel={handleCancel}
                footer={null}
              >
                {active === 'project' && <Projects data={data.projects} />}
                {active === 'companies' && <CompanyList data={data.companies} />}
              </Modal>
            </Container>
          </ContentWrapper>
        </>
      ) : (
        <div
          style={{
            minHeight: '150px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Spin />
        </div>
      )}
    </Wrapper>
  );
};

export default MyProfile;
