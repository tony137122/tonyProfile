import React from 'react';
import Button from '@iso/ui/Antd/Button/Button';
import AvatarCard from '@iso/components/AvatarCard/AvatarCard';
import Wrapper, { ProjectsList, ListItem } from './Projects.styles';

const Projects = ({ data }) => {
  return (
    <Wrapper>
      <h3>
        <strong>{data.length}</strong> Projects
      </h3>
      <ProjectsList>
        {data.length > 0 &&
          data.map(projects => (
            <ListItem key={`projects-key${projects.id}`}>
              <AvatarCard avatar={projects.avatar} name={projects.name} />
              <Button>Detail</Button>
            </ListItem>
          ))}
      </ProjectsList>
    </Wrapper>
  );
};

export default Projects;
