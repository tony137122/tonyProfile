import React from 'react';
import Button from '@iso/ui/Antd/Button/Button';
import AvatarCard from '@iso/components/AvatarCard/AvatarCard';
import Wrapper, { Companies, ListItem } from './Companies.styles';

const CompanyList = ({ data }) => {
  return (
    <Wrapper>
      <h3>
        <strong>{data.length}</strong> Companies
      </h3>
      <Companies>
        {data.length > 0 &&
          data.map(follower => (
            <ListItem key={`follower-key${follower.id}`}>
              <AvatarCard avatar={follower.avatar} name={follower.name} />
              <Button>Companies</Button>
            </ListItem>
          ))}
      </Companies>
    </Wrapper>
  );
};

export default CompanyList;
